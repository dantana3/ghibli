import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css';

import AppPeople from './AppPeople';
import AppFilm from './AppFilm';

class App extends Component {
  render(){
    return (
      <div>
        <AppPeople />
        <AppFilm />
      </div>
    )
  }
}

export default App;

