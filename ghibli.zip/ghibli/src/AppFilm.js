import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css';

import axios from 'axios'
import { connect } from 'react-redux'
import { filmHasErrored, filmIsLoading, filmFetchDataSuccess } from './state/actions';

class AppFilm extends Component {
  constructor(props) {
    super(props)

    this.state = {
      // appfilm: ''
    }
//    this.api_site = "https://ghibliapi.herokuapp.com/films" 
  }

  fetchData(api_site) {
    this.props.appfilmIsLoading()

    axios.get(api_site)
      .then((response) => {
        // if (!response.ok) {
        //   throw Error(response.statusText);
        // }
        console.log(response)
        this.props.appfilmFetchDataSuccess(response)
      })
      .catch(() => this.props.appfilmHasErrored())
  }

  componentDidMount() {
    console.log(this.props);
//    this.fetchData(this.props.appPerson.films[0]);
  }

  filmMap(filmObject, idx) {
    let genderIcon = "icon-ill-happyface"
    if (filmObject.gender.toLowerCase() === "male")
    {
      genderIcon = "icon-ill-maleavatar"
    }
    else if (filmObject.gender.toLowerCase() === "female")
    {
      genderIcon = "icon-ill-femaleavatar"
    }

    let breakRow = "";
    if (idx === 4)
      breakRow = <br key={"breakRowKey" + idx} />;

    return (
      <span key={"personTieTogetherSpan" + idx} >
      <div key={'film' + idx} style={{display: 'inline-block', width: '80px'}}>
        <span key={"genderPic" + idx} className={"icon-illustrative " + genderIcon}></span>
        <div key={'filmName'+ idx}>
          {filmObject.name}
        </div>
      </div>
      {breakRow}
      </span>
    )
  }



  render() {
    console.log(this.props)
    return (
      <div className="App">
        {this.props.appPerson !== undefined ? this.props.appPerson.data.description : ""}
      </div>
    );
  }
}

const getStateFromReduxPassToAppComponentAsProps = (state) => {
  return {
    appPerson: state.stateSelectedPerson,
    appFilms: state.stateSelectedFilms
  }
}

const getDispatchFromReduxToAppComponentAsProps = (dispatch) => {
  return {
    appfilmHasErrored() {
      dispatch(filmHasErrored())
    },
    appfilmIsLoading() {
      dispatch(filmIsLoading())
    },
    appfilmFetchDataSuccess(appTemp) {
      dispatch(filmFetchDataSuccess(appTemp))
    }
  }
}

export default connect(getStateFromReduxPassToAppComponentAsProps, getDispatchFromReduxToAppComponentAsProps)(AppFilm)

