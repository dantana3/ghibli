import {
  PEOPLE_HAS_ERRORED, PEOPLE_IS_LOADING, PEOPLE_FETCH_DATA_SUCCESS,
  FILM_HAS_ERRORED, FILM_IS_LOADING, FILM_FETCH_DATA_SUCCESS, SELECT_PERSON
} from './actions'

const intialState = {
  statePeople: [],
  stateIsLoading: false,
  stateIsError: false,
  stateSelectedPerson: undefined,
  stateSelectedFilms: undefined,
  stateFilmIsLoading: false,
  stateFilmIsError: false
}

function reducer(state = intialState, action) {
  switch (action.type) {
    case PEOPLE_HAS_ERRORED:
      return { ...state, stateIsError: action.payload }

    case PEOPLE_IS_LOADING:
      return { ...state, stateIsLoading: action.payload }

    case PEOPLE_FETCH_DATA_SUCCESS:
      return { ...state, statePeople: action.payload }

    case FILM_HAS_ERRORED:
      return { ...state, stateFilmIsError: action.payload }

    case FILM_IS_LOADING:
      return { ...state, stateFilmIsLoading: action.payload }

    case FILM_FETCH_DATA_SUCCESS:
      return { ...state, stateSelectedFilms: action.payload }

    case SELECT_PERSON:
      return { ...state, stateSelectedPerson: action.payload }

    default:
      return state;
  }
}

export default reducer;