import reducer from './reducers'
import { createStore, compose, applyMiddleware } from 'redux';
import thunk from 'redux-thunk'

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  reducer,
  composeEnhancers(
    // window.devToolsExtension ? window.devToolsExtension() : f => f
    applyMiddleware(thunk.withExtraArgument('https://ghibliapi.herokuapp.com')),
  )
)

export default store;
