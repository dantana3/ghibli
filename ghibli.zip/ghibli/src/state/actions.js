export const PEOPLE_HAS_ERRORED = 'PEOPLE_HAS_ERRORED'
export const PEOPLE_IS_LOADING = 'PEOPLE_IS_LOADING'
export const PEOPLE_FETCH_DATA_SUCCESS = 'PEOPLE_FETCH_DATA_SUCCESS'
export const FILM_HAS_ERRORED = 'FILM_HAS_ERRORED'
export const FILM_IS_LOADING = 'FILM_IS_LOADING'
export const FILM_FETCH_DATA_SUCCESS = 'FILM_FETCH_DATA_SUCCESS'
export const SELECT_PERSON = 'SELECT_PERSON'

export function peopleHasErrored() {
  return {
      type: PEOPLE_HAS_ERRORED
  };
}

export function peopleIsLoading() {
  return {
      type: PEOPLE_IS_LOADING
  };
}

export function peopleFetchDataSuccess(items) {
  return {
      type: PEOPLE_FETCH_DATA_SUCCESS,
      payload: items
  };
}

export function filmHasErrored() {
  return {
      type: FILM_HAS_ERRORED
  };
}

export function filmIsLoading() {
  return {
      type: FILM_IS_LOADING
  };
}

export function filmFetchDataSuccess(items) {
  return {
      type: FILM_FETCH_DATA_SUCCESS,
      payload: items
  };
}

export function selectPerson(films) {
  return {
      type: SELECT_PERSON,
      payload: films
  };
}